#!/bin/sh
result=$( uname -r)
#H3
if [ "${result}" == "4.4.55" ]; then
	cp /update/h3/* /update/ 
	/update/update_h3.sh
fi
#ROCKCHIP
if [ "${result}" == "4.4.143" ]; then
	cp /userdata/update/rk/* /userdata/update/ 
	/userdata/update/update_rk.sh
fi
sync

