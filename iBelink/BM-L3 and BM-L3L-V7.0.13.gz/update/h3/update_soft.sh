#!/bin/ash
#update cgminer/cgminer.conf/php files etc. for ibelink miner

update_tar=$1

cd /
/usr/local/bin/update_decrypt -d $update_tar
tar zxf $update_tar

if [[ $? != 0 ]]; then
    //echo "Updated failed!<br>"
    echo "<script type='text/javascript'> alert('Updated failed!');location.href='index.php'; </script>";  
    exit 1
fi

cd update
sh update.sh

rm -rf /update /$update_tar

//echo "Updated successfully! <br>"
echo "<script type='text/javascript'> alert('Updated successfully, you should restart to use the new version!');location.href='index.php'; </script>";

sync &
