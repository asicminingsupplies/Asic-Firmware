#!/bin/sh

if [ ! -d "/usr/local/java" ];then
exit 1
fi
cd $(dirname $0)
chown 0:0 *
cp /root/cgminer /root/cgminer_back -rf
#rm /etc/cgminer/name.txt -rf
cp -rf recordboot /etc/init.d/
cp -rf root /etc/crontabs/
mv -f cgminer /root/
if [ ! -d "/etc/tmp_cgminer/" ];then
mkdir /etc/tmp_cgminer/
fi
cp -f /etc/cgminer/cgminer.conf.* /etc/tmp_cgminer/
cp -f cgminer.conf* /etc/cgminer/

if [ ! -d "/home/tnbdev/tmp_cfg/" ];then
mkdir /home/tnbdev/tmp_cfg/
fi
#Create an empty file "force_cover_pool_file" to forcibly cover the mining pool
chmod +x update_cfg
./update_cfg

sync

cp -f /home/tnbdev/tmp_cfg/cgminer.conf.* /etc/cgminer/

rm -f /etc/tmp_cgminer/cgminer.conf.*
rm -f /home/tnbdev/tmp_cfg/cgminer.conf.*

#mv -f *.php /www/
#cp -rf *.ico /www/
#mv -f *.png /www/
#####################-start-###########################
if [ ! -d "/usr/local/java/" ];then
mkdir /usr/local/java/
fi

if [ -f "jre211.tar.gz" ];then
 mv jre211.tar.gz /usr/local/java/
 cd /usr/local/java/
 if [ -d "/usr/local/java/jre" ];then
  rm -rf jre
 fi
 tar zxvf jre211.tar.gz
 rm jre211.tar.gz
 cd /update
fi

if [ -f "app_lib.tar.gz" ];then
 mv app_lib.tar.gz /usr/local/java/
 cd /usr/local/java/
 if [ -d "/usr/local/java/lib" ];then
  rm -rf lib
 fi
 tar zxvf app_lib.tar.gz
 rm app_lib.tar.gz
 cd /update
fi

if [ -f "minerConsole-BFL.jar" ];then
 mv -f minerConsole-BFL.jar /usr/local/java/
fi

if [ -f "cutlib.tar.gz" ];then
 tar zxvf cutlib.tar.gz
 mv cutlib/* /lib/
 rm -rf cutlib cutlib.tar.gz
 cd /update
fi

if [ -f "web-users.json" ];then
 if [ ! -d "/usr/local/java/config" ];then
  mkdir /usr/local/java/config/
 fi 
 mv -f web-users.json /usr/local/java/config/
fi

if [ -f "web-config" ];then
 if [ ! -d "/usr/local/java/config" ];then
  mkdir /usr/local/java/config/
 fi
 mv -f web-config /usr/local/java/config/
fi

if [ -f "lighttpd" ];then
 chmod +x lighttpd
 mv lighttpd /etc/init.d/
 cd /etc/rc.d/
 rm -f  /etc/rc.d/S50lighttpd  
 ln -sf ../init.d/lighttpd S50lighttpd
 rm -f /etc/init.d/jrehttp
 rm -f K45jrehttp S52jrehttp
 cd /update
fi

if [ -f "jrehttp" ];then
 chmod +x jrehttp 
 mv jrehttp /etc/init.d/
 cd /etc/rc.d/
 rm -f  /etc/rc.d/S52jrehttp
 rm -f  /etc/rc.d/K45jrehttp 
 ln -sf ../init.d/jrehttp K45jrehttp
 ln -sf ../init.d/jrehttp S52jrehttp 
 rm -f /etc/init.d/lighttpd
 rm -f S50lighttpd
 cd /update
fi

if [ -f "del_skip_core" ];then
 rm -f /root/skip_bist_result*
fi

#if [ -f "rm-web-php" ];then
#  if [ -f "/etc/init.d/lighttpd" ];then
#       rm -f  /etc/init.d/lighttpd
#       rm -f  /etc/rc.d/S50lighttpd
#  fi
#fi

######################-end-#####################
mv -f xtcminer /etc/init.d/
mv -f system /etc/config/
cp -rf testSer /etc/init.d/
if [ ! -f "/etc/cgminer/cgminer.conf.xtc" ]; then
    ln -sf /etc/cgminer/cgminer.conf.xtc9101 /etc/cgminer/cgminer.conf.xtc
fi
cp /etc/cgminer /etc_bak/ -rf
/etc/init.d/recordboot enable

mv update_soft.sh /usr/local/sbin/update.sh
mv restore.sh /usr/local/sbin/
mv setnetwork.sh /usr/local/sbin/
mv update_decrypt /usr/local/bin/
mv TestServer /usr/local/bin/

rm /var/log* -rf &
#rm /root/rebootRec.txt -rf

#linkpath=$(readlink -f /etc/cgminer/cgminer.conf.xtc)
linkpath="/data/etc/cgminer/cgminer.conf.xtc7122p"
echo $linkpath
ln -sf $linkpath /etc/cgminer/cgminer.conf.xtc

#dd if=uImage of=/dev/nandc && sleep 1 && reboot &
sleep 1 && reboot &

sync