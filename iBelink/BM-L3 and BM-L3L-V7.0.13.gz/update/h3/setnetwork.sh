#!/bin/sh

# Assume that $1 is ip address, $2 is netmask,
# $3 is gateway, $4 is dns server

# Get in the configuration directory
cd /etc/config
if [ $# -lt 3 ] || [ $# -gt 4 ]; then
    ln -sf .network.dhcp network
    if [ "$1" != "keepnet" ]; then
        /etc/init.d/network restart
    fi
    sync
    exit
fi

cat > .network.static << EOF
config interface 'loopback'
    option ifname 'lo'
    option proto 'static'
    option ipaddr '127.0.0.1'
    option netmask '255.0.0.0'

config globals 'globals'
    option ula_prefix 'fdc5:f95f:f33d::/48'

config 'interface' 'lan'
    option 'proto'     'static'
    option 'ifname'    'eth0'
    option 'dns'       '114.114.114.114'
EOF

echo "    option 'ipaddr' '$1'" >> .network.static
echo "    option 'netmask' '$2'" >> .network.static
echo "    option 'gateway' '$3'" >> .network.static

if [ ! -z $4 ]; then
    # the dns will be modified by user
    # delete dns line
    sed -i '/dns/d' .network.static
    echo "    option 'dns' '$4'" >> .network.static

fi
# use the static network configuration
ln -sf .network.static network

# How to handle that if the user's configuration do not work?
#ping -c 1 baidu.com > /dev/null 2>&1
#if [ $? -gt 0 ]; then
#    ln -sf .network.dhcp network
#     /etc/init.d/network restart
#fi


# restart the network
/etc/init.d/network restart
ping -c 1 www.baidu.com > /dev/null 2>&1