#!/bin/sh

restore_network() {
    cp -f /etc_bak/config/.network.static /etc/config
    /usr/local/sbin/setnetwork.sh
}


# After mining the configuration had been linked to the actual one
conf=$(readlink -f /etc/cgminer/cgminer.conf.xtc)

conf_bak="/etc_bak/cgminer/$(basename $conf)" # Factory configuration file
# We should apply the changes to the factory configuration file
# because some comfiguraions can be changed during aging test.

if [[ ! -f $conf_bak ]]; then
    echo "No such configuration file '$conf_bak'"
    # if no such configuration file in etc_bak (old machine system used for new miner)
    # don't touch configuration files
    rm /etc/cgminer/name.txt -rf
    rm /etc/cgminer/pwd -rf
    rm /etc/cgminer/user -rf
    # remove log file if necessary
    #find / -name "rebootRec.txt" -exec rm {} \;
    restore_network
    # Restore miner?
    #cp /data/cgminer /root
    exit 1
fi

# The essential configurations are voltage and pll.
# Get these configurations
vol=$(grep api-voltage $conf)
pll=$(grep api-pll $conf)

# Remove voltage and pll settings from factory configuration file
sed -i.bak -e '/api-voltage/d' -e '/api-pll/d' $conf_bak

# Write the aging-tested configurations
sed -i "/api-zone/a$pll\n$vol" $conf_bak

# It's time to restore!
rm -rf /etc/cgminer
cp -a /etc_bak/cgminer /etc

rm /etc/cgminer/name.txt -rf
rm /etc/cgminer/pwd -rf
rm /etc/cgminer/user -rf

cp -f /etc_bak/macaddr /config/macaddr
cp -f /etc_bak/web-config /usr/local/java/config/web-config
cp -f /etc_bak/web-users.json /usr/local/java/config/web-users.json

# Set the actual configuration file
cd /etc/cgminer
ln -sf /etc/cgminer/$(basename $conf) /etc/cgminer/cgminer.conf.xtc

# remove log file if necessary
#find / -name "rebootRec.txt" -exec rm {} \;

restore_network

# Restore miner?
#cp /data/cgminer /root

sync

/etc/init.d/xtcminer stop
