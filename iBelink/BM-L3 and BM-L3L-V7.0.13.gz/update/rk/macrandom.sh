#!/bin/sh

MACADDR=""
if [ -f /config/macaddr ];then
        echo "read mac address form /config/macaddr"
        MACADDR=`cat /config/macaddr`
fi

if [ ! $MACADDR ]; then
        randomaddr=`openssl rand -hex 3 | sed 's/\(..\)/\1:/g; s/.$//'`
        echo " random addr: $randomaddr"
        MACADDR=`echo 00:bf:b1:$randomaddr`
        echo $MACADDR > /config/macaddr
fi

echo "config mac address: $MACADDR"
ifconfig eth0 down
ifconfig eth0 hw ether $MACADDR
ifconfig eth0 up

sleep 2
if [ ! -f /usr/bin/java ];then 
        mount / -o rw,remount
	ln -fs /usr/lib/defaultJRE/bin/java /usr/bin/java
        mount / -o ro,remount
fi


if [ ! -s /config/brd-info.ckb.json ];then
   echo "copy default board information json file"
   cp /opt/brd-info.ckb.json /config/brd-info.ckb.json
fi

if [ ! -s /config/brd-info.kda.json ];then
   echo "copy default board information json file"
   cp /opt/brd-info.kda.json /config/brd-info.kda.json
fi

