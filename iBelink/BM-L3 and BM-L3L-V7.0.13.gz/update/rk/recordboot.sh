#!/bin/sh

start() {
    echo "system booting at $(date)" > /root/system-boot-time
}

stop() {
    echo "stop"
}

restart() {
    stop
    sleep 1
    start
}
case $1 in
    start)
    start;;
    stop)
    stop;;
    restart)
    restart;;
    *)

esac
