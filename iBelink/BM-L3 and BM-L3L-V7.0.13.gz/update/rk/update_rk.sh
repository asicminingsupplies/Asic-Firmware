#!/bin/sh

if [ ! -d "/usr/local/java" ];then
exit 1
fi
cd $(dirname $0)
chown 0:0 *
cp /bin/cgminer /bin/cgminer_back -rf

mv -f cgminer /bin/
if [ ! -d "/etc/tmp_cgminer/" ];then
mkdir /etc/tmp_cgminer/
fi
cp -f /etc/cgminer/cgminer.conf.* /etc/tmp_cgminer/
cp -f cgminer.conf* /etc/cgminer/

if [ ! -d "/home/tnbdev/" ];then
mkdir /home/tnbdev/
fi

if [ ! -d "/home/tnbdev/tmp_cfg/" ];then
mkdir /home/tnbdev/tmp_cfg/
fi
#Create an empty file "force_cover_pool_file" to forcibly cover the mining pool
#Create an empty file "force_cover_volt_file" to forcibly cover the voltage
chmod +x update_cfg
./update_cfg

sync

cp -f /home/tnbdev/tmp_cfg/cgminer.conf.* /etc/cgminer/

rm -f /etc/tmp_cgminer/cgminer.conf.*
rm -f /home/tnbdev/tmp_cfg/cgminer.conf.*

if [ -f "minerConsole-BFL.jar" ];then
 mv -f minerConsole-BFL.jar /opt/console/
 systemctl restart minerConsole
fi

if [ -f "web-users.json" ];then
 mv -f web-users.json /usr/local/java/config/
fi

if [ -f "web-config" ];then
 mv -f web-config /usr/local/java/config/
fi

if [ -f "del_skip_core" ];then
 rm -f /root/skip_bist_result*
fi


if [ ! -d "/etc_bak/" ];then
mkdir /etc_bak/
cp /usr/macrandom.sh /etc_bak/
cp /config/network/* /etc_bak/
cp /config/macaddr /etc_bak/
cp /usr/local/java/config/* /etc_bak/
fi

cp -rf /etc/cgminer /etc_bak/ 
cp /bin/cgminer /etc_bak/cgminer_bak

#lcd

mv boardtype.conf /etc/cgminer

#systemctl enable recordboot.service

mv restore.sh /usr/local/sbin/
mv macrandom.sh /usr/
mv update_decrypt /usr/local/bin/
mv minerserv /bin/
mv recordboot.sh /usr/local/bin/

#rm /root/rebootRec.txt -rf
#if [ ! -f "/etc/cgminer/cgminer.conf.xtc" ]; then
	linkpath="/etc/cgminer/cgminer.conf.xtc712a"
	echo $linkpath
	ln -sf $linkpath /etc/cgminer/cgminer.conf.xtc
#fi

#linkpath=$(readlink -f /etc/cgminer/cgminer.conf.xtc)

sync
systemctl restart cgminer
#reboot does not have a delay parameter
sleep 1 && reboot &
sleep 1
sync

